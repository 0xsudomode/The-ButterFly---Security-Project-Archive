<? 

include("functions.php");

db_connect();

# clear the cookie
setcookie (session_name(), "", time()-42000, "/", $_SERVER['HTTP_HOST']);

redirect_to_login("/index.php");
exit();

?>


