<?
if (!isset($file_form_flag)) $file_form_flag = 0;
?>
<table width="100%">
        <tr><td>
                <table width="20%" align="center">
                        <tr><td><br><br><br></td></tr>
                </table>
        </td></tr>
        <tr><td>
                <form name="auth1" <? if ($file_form_flag == 1) print "enctype=\"multipart/form-data\""; ?> method = "post">
                <table width="600" align="center">
                        <tr>
                                <td><hr size="1"></td>
                        </tr>
                        <tr>
				<td align="center">
				 <table width="100%">
				  <tr>
					<td align="center">Welcome to the ButterFly application - 
<? 
	if ($admin)
		print "<b>Management Interface</b>";	
	else
		print "Authorised Area";
?>
					</td>

<?
	if ($admin) {
?>
					<td>| <a href="orders_admin.php" class="menu2">All Orders</a> |</td>
<?
	}
	else {
?>
					<td>| <a href="index.php" class="menu2">Items</a> |</td>
					<td>| <a href="orders.php" class="menu2">Orders</a> |</td>
					<td>| <a href="search.php" class="menu2">Search</a> |</td>
<?
	}
?>

					<td>| <a href="logout.php">LOG OUT</a> |</td>
				  </tr>
				 </table>
				</td>
			</tr>
                        <tr>
                                <td><hr size="1"></td>
                        </tr>
                        <tr>
                          <td>

