#!/bin/sh

# global defs
path_bf="/usr/local/butterfly"

#
finish()
{
	echo "failed"
	echo "Exiting ..."
	exit 1
}

#
echo "---------------------------------------------------"
echo " Butterfly application 1.0"
echo "---------------------------------------------------"
echo " Setting up the environment..."
echo ""
# check if proper tools exists in the PATH
printf "Checking tools in PATH:\t\t\t\t"

lack1=0

exist1=`which chroot`
if [ $? -eq 1 ]; then
	lack1=1
fi
exist1=`which mount`
if [ $? -eq 1 ]; then
	lack1=1
fi
exist1=`which id`
if [ $? -eq 1 ]; then
	lack1=1
fi
exist1=`which umount`
if [ $? -eq 1 ]; then
	lack1=1
fi
exist1=`which netstat`
if [ $? -eq 1 ]; then
	lack1=1
fi


if [ $lack1 -eq 1 ]; then
	finish
else
	echo "OK"
fi

#am I root?

printf "Checking privileges of the user:\t\t"

if [ `id -u` -eq 0 ]; then
	echo "OK"
else
	finish	
fi

#are www and mysql account present in the system?

show_help=0
account_www_error=0
our_account_www=0

exist1=`cat /etc/passwd | grep 'bfly1'`
if [ $? -eq 0 ]; then
	#group exist
	#is it butterfly group
	exist1=`cat /etc/passwd| grep 'bfly1:x:2001:2001:'`
	if [ $? -eq 0 ]; then
		our_account_www=1
	else
		account_www_error=1	
	fi
fi

printf "Does ButterFly BFLY1(Apache) user exist?:\t"

if [ $our_account_www -eq 1 ]; then
	echo "YES"
fi

if [ $account_www_error -eq 1 ]; then
	echo "Critical ERROR"
	echo ""
	echo "Other BFLY1 account was detected in your system. The unpacked Buttefly folder structure has wrong system permission."
	echo "You need to REMOVE the Buttefly folder structure, next REMOVE your BFLY1 account, optionally create buttefly BFLY1 account, and then again unpack Buttefly application"
	echo ""
	echo "Exiting ..."
	exit 1
fi

if [ $account_www_error -eq 0  -a  $our_account_www -eq 0 ]; then
	echo "NO - please look below how to create Butterfly bfly1 account"
	show_help=1
fi

account_mysql_error=0
our_account_mysql=0

exist1=`cat /etc/passwd | grep 'bfly2'`
if [ $? -eq 0 ]; then
	#group exist
	#is it butterfly group
	exist1=`cat /etc/passwd| grep 'bfly2:x:2002:2002:'`
	if [ $? -eq 0 ]; then
		our_account_mysql=1
	else
		account_mysql_error=1	
	fi
fi

printf "Does ButterFly BFLY2(MySQL) user exist?:\t"

if [ $our_account_mysql -eq 1 ]; then
	echo "YES"
fi

if [ $account_mysql_error -eq 1 ]; then
	echo "Critical ERROR"
	echo ""
	echo "Other BFLY2 account was detected in your system. The unpacked Buttefly folder structure has wrong system permission."
	echo "You need to REMOVE the Buttefly folder structure, next REMOVE your BFLY2 account, optionally create buttefly BFLY2 account, and then again unpack Buttefly application"
	echo ""
	echo "Exiting ..."
	exit 1
fi

if [ $account_mysql_error -eq 0  -a  $our_account_mysql -eq 0 ]; then
	echo "NO - please look below how to create Butterfly bfly2 account"
	show_help=1
fi


# are ports 80, 3306 available?

printf "Is port 80 available for the ButterFly?:\t"

exist1=`netstat -ltn | grep ':80 '`
if [ $? -eq 0 ]; then
	#something is listening
	finish
else
	echo "YES"
fi

printf "Is port 3306 available for the ButterFly?:\t"

exist1=`netstat -ltn | grep ':3306 '`
if [ $? -eq 0 ]; then
	#something is listening
	finish
else
	echo "YES"
fi


#is dev mounted?

if [ ! -e $path_bf/dev/null ]; then

	printf "Creating DEV structure:\t\t\t\t"

	mount -o bind /dev/ $path_bf/dev

	if [ $? -eq 0 ]; then
		echo "OK"
	else
		finish
	fi

fi

#is it running

if [ -f $path_bf/var/run/httpd.pid ]; then
	echo "Apache is running."
	exit 1
fi
printf "Starting APACHE:\t\t\t\t"

chroot $path_bf /apache/sbin/httpd -k start  > /dev/null 2>&1

i=0
while true; do

        if [ -f $path_bf/var/run/httpd.pid ]; then
		#echo $i
                echo "OK"
                break
	else
		i=`expr $i + 1`

		if [ $i -eq 60 ]; then
			finish
		fi
        fi
        sleep 1
done

# mysql
$path_bf/mysql/sbin/mysql_start.sh


if [ $show_help -eq 1 ]; then

	echo ""
	echo "---------------------------------------------------"
	echo "In order to create ButterFly BFLY1 and BFLY2 enter as root the following commands:"
	echo ""
	echo "groupadd -g 2001 bfly1"
	echo "groupadd -g 2002 bfly2"
	echo ""
	echo "useradd -c \"ButterFly Apache Account\" -d /usr/local/butterfly/ -g bfly1 -s /usr/sbin/nologin -u 2001 bfly1"
	echo "useradd -c \"ButterFly MySQL Account\" -d /usr/local/butterfly/ -g bfly2 -s /usr/sbin/nologin -u 2002 bfly2"
fi

echo ""
echo "---------------------------------------------------"
echo "Please login to the application now:"
echo "http://insecure.butterfly.prv"
echo "http://secure.butterfly.prv"
echo ""
echo "Username:app1 Password:app1"
echo "Username:app2 Password:app2"
echo "Username:admin Password:admin"
echo "---------------------------------------------------"
echo ""

echo "The following network interfaces were detected on this computer:"

echo ""
ifconfig | grep inet | grep -v 127.0.0.1
echo ""
echo "Before you can use the ButterFly application, you need to add "
echo "an entry to local hosts file at your computer This entry should "
echo "point the domains (insecure.butterfly.prv and secure.butterfly.prv) "
echo "to one of the addresses listed above. More info you can find in "
echo "the project document."
echo "---------------------------------------------------"
echo ""

