<? 

require_once ("xajax_core/xajaxAIO.inc.php");

$xajax = new xajax("search_ajax.php");
$xajax->registerFunction("findorders");

$ajax=1;

include("functions.php");


db_connect();	
is_authenticated();


include("header.php");
include("header_html.php");

?>

		<script type="text/javascript">
		function submitForm()
		{
			xajax.$('auth_b1').disabled=true;
			xajax.$('auth_b1').value="please wait...";
			xajax_findorders(document.getElementById('search_id').value);
			return false;
		}
		</script>

		                <table width="100%" align="center">
				<tr>
				 <td>
			                <table width="90%" align="center">
					<tr>
					  <td>Enter keyword to search in the items database:</td>
					  <td><input class="input_norm" name="search_field" id="search_id" type="text" size="30" value="<? print $_REQUEST["search_field"];?>"></td>
					  <td width="100"><input class="form_but" id="auth_b1" name="auth_b1" type="button" value="Search" onClick="submitForm();"></td>
					</tr>
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan="3" align="center">
							<div id="resultsid"></div>
						</td>
					</tr>
				  	</table>
				 </td>
				</tr>
				</table>

<?
	include("footer_html.php");
	include("footer.php");
?>
