<? 

########################################

function db_connect() {

	$link = mysql_connect('localhost', 'test', 'test')
		or log_exit('Could not connect: ' . mysql_error());
	mysql_select_db('test') or app_exit ('Selecting the database failed');

}

function app_exit($mess) {

	print $mess;
	exit();
}

function log_exit($mess) {

	error_log($mess);
}


function db_query($query) {

	$result = mysql_query($query) or app_exit("Could not perform select query - " . mysql_error());
	return $result;
}

function db_query_custom($query) {

	$result = mysql_query($query) or log_exit("Could not perform select query - " . mysql_error());
	return $result;
}


function is_authenticated() {

 global $id_user;
 global $admin;

 ## is user id present in the session?
 
 #resume the session
 session_start();

 if (isset($_SESSION['user'])) {

	# assign a global variable
	$id_user=$_SESSION['user'];

        # session user id present in db table? Is he an admin?
        $res = db_query("select admin from users where id_user='$id_user'");
        if (mysql_num_rows($res) > 0) {

		$row=mysql_fetch_array($res);

		# set a global variable
		$admin=$row[0];

                # just continue
                return 1;

        }
        else {
                # redirect to the login page
                redirect_to_login();
		exit();
        }

 }
 else {
        redirect_to_login();
	exit();
	
 }

}

function is_admin() {

	global $admin;

	if ($admin != 1) {
		redirect_to_login();
	}

}

function redirect_to_login($str="") {

        #redirect user to the login page

        $redir = "Location: ";
        if ($_SERVER['SERVER_PORT'] == 80) $redir .= "http://";
        else $redir .= "https://";

        $redir .= $_SERVER['HTTP_HOST']."/login.php?req=";

	if ($str != "") $redir .= $str;
	else $redir .= $_SERVER['REQUEST_URI'];


        header($redir);

}

function redirect_custom($page) {

        #redirect user to a custom page

        $redir = "Location: ";
        if ($_SERVER['SERVER_PORT'] == 80) $redir .= "http://";
        else $redir .= "https://";

        $redir .= $_SERVER['HTTP_HOST']."/$page";

        header($redir);
        exit();

}

?>
