<? 

include("functions.php");

db_connect();	

is_authenticated();
is_admin();

include("header.php");
include("header_html.php");


#for checking if BUY was submitted use:
 # weak, but easy and quick     - strpos ( a === false )
 # secure                       - regexp buy[0-9]+ (plus BUY value checking)
foreach($_REQUEST as $k => $v) {

        # was any ACCEPT submitted in $_REQUEST array
        if ( !( strpos($k,"accept") === false ) and $v="BUY") {
                # for id extraction use SUBSTR
                $acc_id=substr($k,6);

                # update the order status to accepted
                db_query("update orders set status=1 where id_order=".$acc_id);
        }
}


?>
		                <table width="100%" align="center">
				<tr>
				 <td align="center">

<?
	if (isset($_REQUEST["details"])) {
?>

			                <table width="80%" align="center">
					<tr>
					  <td colspan="2">
					   Details of the order number <? print $_REQUEST["details"]; ?>:
					  </td>
					</tr>
					<tr>
					  <td colspan="2">
					   &nbsp;
					  </td>
					</tr>
<?

		# list all items
		$res = db_query("select orders.id_order, items.name, items.price, order_items.amount, orders.comment, orders.status from (items JOIN order_items on items.id_item=order_items.id_item) JOIN orders ON orders.id_order=order_items.id_order where orders.id_order=".$_REQUEST["details"]." order by order_items.id_item asc");

		if (mysql_num_rows($res) > 0) {


			$i=1;
			$comment="";
			while ($row=mysql_fetch_array($res)) {

				print "
                                        <tr>
                                          <td>$i.</td>
                                          <td>$row[3] x $row[1]</td>
                                          <td>".$row[3]*$row[2]."$</td>
                                        </tr>

				";
				$i+=1;
				$comment=$row[4];
				$status=$row[5];
			}

			# what is the status of the order
			print "
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td>&nbsp;</td>
						<td>Status: 
			";

			if ($status == 1) print "accepted";
			else print "<b>not accepted</b>";

			print "
						</td>
					</tr>
			";

			# is there a document uploaded by a user?

			$uploaddir = $_SERVER['DOCUMENT_ROOT']."/files/";
			$uploaddir .= $_REQUEST['details'].".gif";

			if (file_exists($uploaddir)) {
				print "
					<tr>
						<td colspan=\"3\">The document with additional requirements: <a href=\"preview.php?f=".$_REQUEST['details']."\" target=\"_blank\">preview (IE)</a></td>
					</tr>
				";
			}

			print "
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan=\"3\">Comment:</td>
					</tr>
					<tr>
						<td colspan=\"3\">$comment</td>
					</tr>
			";
	

		}
		else {
			print "
                                        <tr>
                                          <td colspan=\"2\">
                                            No orders were submitted.
                                          </td>
                                        </tr>

			";
		}


?>
					</table>


<?
	}
	else {
?>
			                <table width="80%" align="center">
					<tr>
					  <td colspan="4">
					   The following orders were submitted:
					  </td>
					</tr>
					<tr>
					  <td colspan="4">
					   &nbsp;
					  </td>
					</tr>
<?
		# list all items
		$res = db_query("select id_order,status from orders order by id_order asc");

		if (mysql_num_rows($res) > 0) {


			$i=1;
			while ($row=mysql_fetch_array($res)) {

				print "
                                        <tr>
                                          <td>$i.</td>
                                          <td><a href=\"orders_admin.php?details=$row[0]\">Order number $row[0]</a>.</td>
				";

				if ($row[1] == 1) print "<td>accepted</td>";
				else print "<td><b>not accepted</b></td>";

				if ($row[1] == 1) print "<td>&nbsp;</td>";
				else print "<td><input class=\"form_but\" name=\"accept$row[0]\" type=\"submit\" value=\"Accept\"></td>";

				print " </tr>";

				$i+=1;
			}
	

		}
		else {
			print "
                                        <tr>
                                          <td colspan=\"4\">
                                            No orders were submitted.
                                          </td>
                                        </tr>

			";
		}


?>
					</table>



<?
	}

?>

				 </td>
				</tr>
				</table>

<?
	include("footer_html.php");
	include("footer.php");
?>
