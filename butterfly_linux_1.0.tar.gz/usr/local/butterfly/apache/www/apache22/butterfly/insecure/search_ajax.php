<?
include("functions.php");


db_connect();

require_once ("xajax_core/xajaxAIO.inc.php");

$xajax = new xajax("search_ajax.php");
$xajax->registerFunction("findorders");


function findorders($value) {

	$objResponse = new xajaxResponse();

	$bError = false;
	
	if (trim($value) == ""){
		$objResponse->alert("Please enter a keyword.");
		$bError = true;
	}

	if (!$bError){

	        $res = db_query_custom("select id_item,name,price from items where name like '%$value%' order by name asc");
	        #$res = db_query_custom("select id_item,name,price from items where name like '%".addslashes($value)."%' order by name asc");

		if ($res != false) { 

	          if (mysql_num_rows($res) > 0) {

	                $i=1;

			$res_items = "<table>";
			
	                while ($row=mysql_fetch_array($res)) {

				$res_items .= "<tr>";
				$res_items .= "<td>$i.</td>";
				$res_items .= "<td><b>".$row["1"]."</b></td>";
				$res_items .= "<td>-</td>";
				$res_items .= "<td>".$row["2"]."$</td>";
 				$res_items .= "</tr>";
				
				$i += 1;
			}

			$res_items .= "</table>";

		  }
		  else 

			$res_items = "No items were found.";
		}
		else {

			$res_items = "Error occurred";
		}

		$objResponse->assign("resultsid","innerHTML",$res_items);
	}

	$objResponse->assign("auth_b1","value","Search");
	$objResponse->assign("auth_b1","disabled",false);
	return $objResponse;
	
}

$xajax->processRequest();
?>
