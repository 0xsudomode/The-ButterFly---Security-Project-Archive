<? 

include("functions.php");

db_connect();	
is_authenticated();


# if a user is an administrator ... redirect him to a new page
if ($admin) {
	redirect_custom("orders_admin.php");
	exit();
}



#for checking if BUY was submitted use:
 # weak, but easy and quick   	- strpos ( a === false )
 # secure 			- regexp buy[0-9]+ (plus BUY value checking)
foreach($_REQUEST as $k => $v) {

	# was any BUY submitted in $_REQUEST array 
	if ( !( strpos($k,"buy") === false ) and $v="BUY") {	
		# for id extraction use SUBSTR
		$buy_id=substr($k,3);

		# add the item to the basket
		db_query("insert into basket (id_user,id_item,amount) values ('".$id_user."','".$buy_id."','".$_REQUEST["amount$buy_id"]."')");
	}
}

# clear the basket, if needed

if (isset($_REQUEST["clear"])) {

	db_query("delete from basket where id_user='".$id_user."'");

}

# order placed?
if (isset($_REQUEST["order"])) {

	redirect_custom("orders.php?order=1");
	exit();
}


include("header.php");
include("header_html.php");

?>
		                <table width="100%" align="center">
				<tr>
				 <td>
			                <table width="80%" align="center">
					<tr>
					  <td colspan="5">
					    The following items are available:
					  </td>
					</tr>
<?
	# list all items
	$res = db_query("select id_item,name,price from items order by name asc");

	if (mysql_num_rows($res) > 0) {


		$i=1;

		while ($row=mysql_fetch_array($res)) {

			print "
                                        <tr>
                                          <td>$i.</td>
                                          <td>$row[1]</td>
                                          <td>$row[2]$</td>
                                          <td><input class=\"input_panel\" name=\"amount$row[0]\" type=\"text\" size=\"1\" value=\"1\"></td>
                                          <td><input class=\"form_but_small\" name=\"buy$row[0]\" type=\"submit\" value=\"BUY\"></td>
                                        </tr>

			";

			$i+=1;

		}
	
	}
	else {
		print "
                                        <tr>
                                          <td colspan=\"5\">
                                            No items available.
                                          </td>
                                        </tr>

		";
	}


?>
					</table>
				 </td>
				 <td>
				  <table width="100%">
				    <tr>
					<td align="right">
<?
	$res = db_query("select items.name, items.price, basket.amount from items JOIN basket on items.id_item=basket.id_item where basket.id_user='".$id_user."' order by basket.id_basket asc");

	if (mysql_num_rows($res) > 0) {

		print "
						<table width=\"60%\">
						  <tr>
							<td colspan=\"3\" align=\"center\">Your basket:</td>
						  </tr>
		";

		$i=1;

		while ($row=mysql_fetch_array($res)) {

			print "
						   <tr>
                                          		<td class=\"tresc\">$i.</td>
                                          		<td class=\"tresc\">$row[2] x $row[0]</td>
                                          		<td class=\"tresc\">".$row[2]*$row[1]."$</td>
                                        	   </tr>

			";

			$i+=1;

		}
		
		print "
						    <tr>
							<td align=\"center\" colspan=\"3\">
								<input class=\"form_but\" name=\"order\" type=\"submit\" value=\"Place the order\">&nbsp;
								<input class=\"form_but\" name=\"clear\" type=\"submit\" value=\"Clear\">
							</td>
						    </tr>
						</table>
		";
	
	}
	else {
		print "Your basket is empty";
	}
?>
					</td>
				    </tr>
				  </table>
				 </td>
				</tr>
				</table>

<?
	include("footer_html.php");
	include("footer.php");
?>
