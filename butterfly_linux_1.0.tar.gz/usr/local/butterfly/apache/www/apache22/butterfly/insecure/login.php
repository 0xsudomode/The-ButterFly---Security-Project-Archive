<? 

include("functions.php");

$user_auth="";
db_connect();



########################################
### is a req GET parameter set?

if (!isset($_GET['req']) or $_GET['req'] == "") {
	#just exit ...
	exit();
}

########################################


# the form submitted?
if (isset($_REQUEST['auth_b1'])) {

	
	# check if a user exists and a password is correct
	$username=$_REQUEST['username'];
	$password=$_REQUEST['password'];
	$res = db_query("select id_user from users where username='".addslashes($username)."' and password='".addslashes($password)."'");
	if (mysql_num_rows($res) == 1) {

		#create a session
		session_start();

		$row=mysql_fetch_array($res); #list id_user

		# associate the session with the application user
		$_SESSION['user']=$row[0];

		#redirect user to the requested resource
	
		$redir = "Location: ";
		if ($_SERVER['SERVER_PORT'] == 80) $redir .= "http://";
		else $redir .= "https://";

		$redir .= $_SERVER['HTTP_HOST'];

		# add requested resource link
		$redir .= $_GET['req'];

		header($redir);
		exit();				
	}
	else {
		$user_auth="bad";
	}
}

include("header.php"); 


?>
<table width="100%">
	<tr><td>
		<table width="20%" align="center">
			<tr><td><br><br><br></td></tr>
		</table>
	</td></tr>
	<tr><td>
		<form name = "auth1" method = "post">
		<table width="200" align="center">
			
			<tr>
				<td colspan="2"><hr size="1" width="200"></td>
			</tr>
			<tr><td colspan="2" align="center">Welcome to the ButterFly application</td></tr>
			<tr>
				<td colspan="2"><hr size="1" width="200"></td>
			</tr>
<?

if ($user_auth == "bad") {

	print "

			<tr>
				<td colspan=\"2\" class=\"error\" align=\"center\">Login or password incorrect</td>
			</tr>
			<tr>
				<td colspan=\"2\"><hr size=\"1\" width=\"200\"></td>
			</tr>
	";

}


?>
			<tr>
				<td>Login:</td>
				<td><input class="input_norm" name="username" type="text" value="<? print $_REQUEST['username']; ?>"></td>
			</tr>
			<tr>
				<td>Password:</td>
				<td><input class="input_norm" name="password" type="password"></td>
			</tr>
			<tr>
				<td colspan="2"><hr size="1" width="200"></td>
			</tr>
			<tr>
				<td><input class="form_but" type="reset" value="Reset"></td>
				<td><input class="form_but" name="auth_b1" type="submit" value="Send"></td>
			</tr>
			<tr>
				<td colspan="2"><hr size="1" width="200"></td>
			</tr>
			<tr>
				<td colspan="2" align="center">To log to standard user use:<br>
							 app1:app1<BR>
							 app2:app2<BR><BR>
				To log to administator account use:<br>
				admin:admin


				</td>
			</tr>
			<tr>
				<td colspan="2"><hr size="1" width="200"></td>
			</tr>
		</table>
		</form>
	</td></tr>
	<tr><td>
		<table width="300" align="center">
			<tr>
				<td colspan="2" align="center" class="error">
This application is for educational purposes only.<br><br>
It contains a lot of security vulnerabilities, which can compromise the machine, where it is installed.
				</td>
			</tr>
			<tr>
				<td colspan="2"><hr size="1" width="300"></td>
			</tr>

		</table>
	</td></tr>
</table>
<? include("footer.php"); ?>
