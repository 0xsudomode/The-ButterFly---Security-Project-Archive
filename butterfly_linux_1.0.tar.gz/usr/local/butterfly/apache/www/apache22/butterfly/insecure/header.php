<?
	if (!isset($ajax)) $ajax=0;
?>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
  <head>
    <TITLE>ButterFly v1.0</TITLE>
 
    <META http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
    <link rel="stylesheet" type="text/css" href="styles.css">
    <script type="text/javascript">
	function order_choice(order_nr) {
		document.auth1.order_nr.value=order_nr;
		document.auth1.submit();
	}
    </script>
    <? if ($ajax) $xajax->printJavascript(); ?>
  </head>
<body bgcolor="#ffffff" style="margin: 0px;">
