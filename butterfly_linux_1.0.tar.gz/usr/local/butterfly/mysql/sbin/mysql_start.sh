#!/bin/sh

pid_file="/usr/local/butterfly/var/run/mysqld/mysqld.pid"

if [ -f $pid_file ]; then
        echo "MYSQL is running ... Exiting ..."
        exit
fi


printf "Starting MYSQL:\t\t\t\t\t"
/usr/local/butterfly/mysql/bin/mysqld_safe --log=/var/log/mysql.log > /dev/null 2>&1 & 

i=0
while true; do

        if [ -f $pid_file ]; then
		#echo $i
                echo "OK"
                break
        else
                i=`expr $i + 1`

                if [ $i -eq 30 ]; then
                        echo failed
                fi
        fi
        sleep 1
done
