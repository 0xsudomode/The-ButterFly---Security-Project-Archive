#!/bin/sh

# global defs
path_bf="/usr/local/butterfly"

echo ""
## apache

#is it running

if [ ! -f $path_bf/var/run/httpd.pid ]; then
	echo "Apache is not running."
	echo "Exiting ..."
	exit 1
fi
printf "Stopping APACHE:\t\t\t\t"

chroot $path_bf /apache/sbin/httpd -k stop  > /dev/null 2>&1

sleep 1

while true; do

	if [ ! -f $path_bf/var/run/httpd.pid ]; then
		echo "OK"
		break
	fi
	sleep 1
done 

# mysql
$path_bf/mysql/sbin/mysql_stop.sh

# destroy dev

printf "Removing DEV structure:\t\t\t\t"
umount $path_bf/dev

if [ ! -e $path_bf/dev/null ]; then
	echo "OK"
else
	echo "failed"
fi

echo ""

