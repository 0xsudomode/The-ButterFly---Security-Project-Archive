<? 

include("functions.php");

db_connect();	
is_authenticated();

# if a user is an administrator ... redirect him to a new page
if ($admin) {
        redirect_custom("orders_admin.php");
        exit();
}


# special enctype of the form for uploading files
if (isset($_REQUEST["order"]) and !isset($_REQUEST["confirm"])) $file_form_flag=1;

include("header.php");
include("header_html.php");

?>
		                <table width="100%" align="center">
				<tr>
				 <td align="center">

<?

# order placed. show to a user the order summary
if (isset($_REQUEST["order"]) and !isset($_REQUEST["confirm"])) {


?>
			                <table width="80%" align="center">
					<tr>
					  <td colspan="4">
					   Would you like to place the following order:
					  </td>
					</tr>
					<tr>
					  <td colspan="4">
					   &nbsp;
					  </td>
					</tr>
<?
	# list all items
	$res = db_query("select items.name, items.price, basket.amount from items JOIN basket on items.id_item=basket.id_item where basket.id_user='".$id_user."' order by basket.id_basket asc");

	if (mysql_num_rows($res) > 0) {


		$i=1;
		$sum=0;
		while ($row=mysql_fetch_array($res)) {

			print "
                                        <tr>
                                          <td>$i.</td>
                                          <td>$row[2] x $row[0]</td>
                                          <td>=</td>
                                          <td>".$row[2]*$row[1]."$</td>
                                        </tr>

			";
			$sum+=$row[2]*$row[1];
			$i+=1;

		}
	
		
		print "
                                        <tr>
                                          <td>&nbsp;</td>
                                          <td>&nbsp;</td>
                                          <td colspan=\"2\"><hr size=\"1\"></td>
                                        </tr>
                                        <tr>
                                          <td>&nbsp;</td>
                                          <td>&nbsp;</td>
                                          <td>&nbsp;</td>
                                          <td>$sum$</td>
                                        </tr>
                                        <tr>
                                          <td colspan=\"4\">Document with additional requirements in graphical form (.gif):</td>
					</tr>
                                        <tr>
                                          <td colspan=\"4\"><input name=\"uploaddoc\" type=\"file\" class=\"input_norm\"></td>
					</tr>
                                        <tr>
                                          <td colspan=\"4\">Comment:</td>
					</tr>
                                        <tr>
                                          <td colspan=\"4\"><textarea rows=\"3\" cols=\"86\" name=\"comment\" class=\"textarea_norm\"></textarea></td>
					</tr>
                                        <tr>
                                          <td align=\"center\" colspan=\"4\"><input class=\"form_but\" name=\"confirm\" type=\"submit\" value=\"Confirm\"></td>
					</tr>
		";

	}
	else {
		print "
                                        <tr>
                                          <td colspan=\"4\">
                                            No items were added to the basket.
                                          </td>
                                        </tr>

		";
	}


?>
					</table>

<?
}
elseif (isset($_REQUEST["order"]) and isset($_REQUEST["confirm"])){
# new order submitted, so process it ...

	# use SQL transaction to move the basket to the orders and order_items tables, and then remove the content of the basket
	## Note:
	# in order to use transactions in MYSQL, you have to transactions safe storage for example: InnoDB

	db_query("START TRANSACTION");
	db_query("BEGIN");

	#
	if (!db_query("INSERT INTO orders(id_user,comment, status) VALUES ('".$id_user."','".$_REQUEST["comment"]."',0)")) {
		db_query("ROLLBACK");
		exit();
	}

	# get the id of the new created order
	$id_order=mysql_insert_id();

	$res = db_query("SELECT id_item, amount FROM basket where id_user=".$id_user);

	while ($row=mysql_fetch_array($res)) {

		if (!db_query("INSERT INTO order_items(id_order,id_item,amount) VALUES(".$id_order.",".$row[0].",".$row[1].")")) {
			db_query("ROLLBACK");
			exit();
		}
	}

	if (!db_query("DELETE FROM basket WHERE id_user=".$id_user)) {
		db_query("ROLLBACK");
		exit();
	}

	# did a user uploaded a file?
	if(!empty($_FILES['uploaddoc']['tmp_name'])) {

		$uploaddir = $_SERVER['DOCUMENT_ROOT']."/files/";
		$uploaddir .= $id_order.".gif";

		if ($_FILES['uploaddoc']['type'] != "image/gif") {
			echo "You are allowed to upload .gif images.";
			db_query("ROLLBACK");
			exit();
		}

		//Copy the file to some permanent location
		if(!move_uploaded_file($_FILES['uploaddoc']['tmp_name'], $uploaddir)) {
			echo "There was a problem when uploading the new file.";
			db_query("ROLLBACK");
			exit();
		}
	}


	db_query("COMMIT");

	print "Your order was submitted. Thank you.";
	print "<br><br>";
	print "<a href=\"orders.php\">View your all order</a>";
}
else {

	#show detail of particular order
	if (isset($_REQUEST["order_nr"])) {
?>

			                <table width="80%" align="center">
					<tr>
					  <td colspan="2">
					   Details of the order number <? print $_REQUEST["order_nr"]; ?>:
					  </td>
					</tr>
					<tr>
					  <td colspan="2">
					   &nbsp;
					  </td>
					</tr>
<?
		# list all items
		$res = db_query("select orders.id_order, items.name, items.price, order_items.amount, orders.comment, orders.status from (items JOIN order_items on items.id_item=order_items.id_item) JOIN orders ON orders.id_order=order_items.id_order where orders.id_order=".$_REQUEST["order_nr"]." and orders.id_user=".$_REQUEST["id"]." order by order_items.id_item asc");

		if (mysql_num_rows($res) > 0) {


			$i=1;
			$comment="";
			while ($row=mysql_fetch_array($res)) {

				print "
                                        <tr>
                                          <td>$i.</td>
                                          <td>$row[3] x $row[1]</td>
                                          <td>".$row[3]*$row[2]."$</td>
                                        </tr>

				";
				$i+=1;
				$comment=$row[4];
				$status=$row[5];
			}

                        print "
                                        <tr>
                                                <td>&nbsp;</td>
                                        </tr>
                                        <tr>
                                                <td>&nbsp;</td>
                                                <td>&nbsp;</td>
                                                <td>Status:
                        ";

			# status of the order
                        if ($status == 1) print "accepted";
                        else print "<b>not accepted</b>";

                        print "
                                                </td>
                                        </tr>
                        ";


			# is there a document uploaded by a user?

			$uploaddir = $_SERVER['DOCUMENT_ROOT']."/files/";
			$uploaddir .= $_REQUEST['order_nr'].".gif";

			if (file_exists($uploaddir)) {
				print "
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan=\"3\">The document with additional requirements: <a href=\"preview.php?f=".$_REQUEST['order_nr']."\" target=\"_blank\">preview (IE)</a></td>
					</tr>
				";
			}

			print "
					<tr>
						<td>&nbsp;</td>
					</tr>
					<tr>
						<td colspan=\"3\">Comment:</td>
					</tr>
					<tr>
						<td colspan=\"3\">$comment</td>
					</tr>
			";
	

		}
		else {
			print "
                                        <tr>
                                          <td colspan=\"2\">
                                            No orders were submitted.
                                          </td>
                                        </tr>

			";
		}


?>
					</table>


<?
	}
	else {
	# in all other cases, just show the history of user's orders.
?>
					<input type="hidden" name="id" value="<? print $id_user; ?>">
					<input type="hidden" name="order_nr" value="">
			                <table width="80%" align="center">
					<tr>
					  <td colspan="2">
					   You submitted the following orders:
					  </td>
					</tr>
					<tr>
					  <td colspan="2">
					   &nbsp;
					  </td>
					</tr>
<?
		# list all items
		$res = db_query("select id_order,status from orders where id_user=".$id_user);

		if (mysql_num_rows($res) > 0) {


			$i=1;
			while ($row=mysql_fetch_array($res)) {

				print "
                                        <tr>
                                          <td>$i.</td>
                                          <td><a href=\"javascript: order_choice('$row[0]');\">Order number $row[0]</a>.</td>
				";

                                if ($row[1] == 1) print "<td>accepted</td>";
                                else print "<td><b>not accepted</b></td>";

				print "
                                        </tr>

				";
				$i+=1;
			}
	

		}
		else {
			print "
                                        <tr>
                                          <td colspan=\"2\">
                                            No orders were submitted.
                                          </td>
                                        </tr>

			";
		}


?>
					</table>



<?
	}
}
?>

				 </td>
				</tr>
				</table>

<?
	include("footer_html.php");
	include("footer.php");
?>
