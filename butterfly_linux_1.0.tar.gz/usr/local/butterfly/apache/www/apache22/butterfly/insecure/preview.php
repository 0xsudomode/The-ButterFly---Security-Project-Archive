<? 

include("functions.php");


db_connect();	
is_authenticated();

## include additional functions
# does a global variable exist?

if ($ourpath == "") {
	#if it doesn't exist, additionally check for this variable in GET/POST request, just in case
	$ourpath=$_REQUEST["ourpath"];
}

# if the variable is set, include additional set of functions 
if ($ourpath != "") {
	include($ourpath."functions_add.php");
}

$path = $_SERVER['DOCUMENT_ROOT']."/files/";
$path .= $_REQUEST['f'].".gif";

header('Content-Type: application/octet-stream');

### secure
#header("Content-Disposition: attachment; filename=test.gif");


readfile($path);
exit();
?>
