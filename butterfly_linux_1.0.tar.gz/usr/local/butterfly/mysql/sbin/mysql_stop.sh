#!/bin/sh

# kill nicely MYSQL database

pid_file="/usr/local/butterfly/var/run/mysqld/mysqld.pid"

if [ ! -f $pid_file ]; then
        echo "MYSQL is not running ... Exiting ..."
        exit
fi


printf "Stopping MYSQL:\t\t\t\t\t"
pid=`cat $pid_file`

kill -15 $pid

while true; do

        if [ ! -f $pid_file ]; then
                break
        fi
        sleep 1
done

echo "OK"
